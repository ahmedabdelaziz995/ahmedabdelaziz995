package app.controller;

import app.view.JFrame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Controller implements ActionListener {

    private JFrame frame;

    public Controller(JFrame frame) {
        this.frame = frame;
    }
    
    
    @Override
    public void actionPerformed(ActionEvent e) {

        System.out.println("Welcome");
        {
            switch (e.getActionCommand()) {
                case "New Invoice":
                    newInvoice();
                    break;
                case "Delete Invoice":
                    deleteInvoice();
                    break;
                case "New Item":
                    newItem();
                    break;
                case "Delete Item":
                    deleteItem();
                    break;
                case "Load Files":
                    loadFiles();
                    break;
                case "Save Data":
                    saveData();
                    break;

            }

        }
    }

    private void newInvoice() {
    }

    private void deleteInvoice() {
    }

    private void newItem() {
    }

    private void deleteItem() {
    }

    private void loadFiles() {
    }

    private void saveData() {
    }
}
